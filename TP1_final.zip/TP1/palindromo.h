
/**
 * UNIVERSIDADE FEDERAL DE ALFENAS (UNIFAL-MG)
 * Bacharelado em Ciência da Computação
 * Disciplina: AEDS II - DCE792
 * Professor: Iago Augusto de Carvalho
 * 
 * Trabalho Prático 1 - Verificador de Palíndromos
 * 
 * Integrantes do Grupo:
 * - Gabriela Mazon Rabello de Souza - 2025.1.08.006
 * - Luiz Gabriel da Silva Cabrera - 2024.1.08.047
 * - Murilo Antonio da Silva - 2025.1.08.019
 *  
 * Arquivo Palindromo.h
 * Data: 23/09/2025
 */


#ifndef PALINDROMO_H
#define PALINDROMO_H

#include <stdio.h>
#include <stdlib.h>

// ========================================
// DEFINIÇÕES DAS ESTRUTURAS DE DADOS
// ========================================

typedef struct No {
    char dado;
    struct No* proximo;
} No;

typedef struct {
    No* inicio;
} Lista;

typedef struct {
    No* topo;
} Pilha;

typedef struct {
    No* inicio;
    No* fim;
} Fila;

// ========================================
// FUNÇÕES DA LISTA
// ========================================

Lista* criarLista();
void inserirLista(Lista* lista, char elemento);
void liberarLista(Lista* lista);

// ========================================
// FUNÇÕES DA PILHA
// ========================================

Pilha* criarPilha();
void empilhar(Pilha* pilha, char elemento);
char desempilhar(Pilha* pilha);
int pilhaVazia(Pilha* pilha);
void liberarPilha(Pilha* pilha);

// ========================================
// FUNÇÕES DA FILA
// ========================================

Fila* criarFila();
void enfileirar(Fila* fila, char elemento);
char desenfileirar(Fila* fila);
int filaVazia(Fila* fila);
void liberarFila(Fila* fila);

// ========================================
// FUNÇÕES AUXILIARES
// ========================================

int ehAlfanumerico(char c);
char paraMinusculo(char c);
void limparTexto(char* entrada, char* saida);
int contarCaracteres(char* texto);
int verificarPalindromo(char* texto);
int lerLinha(FILE* arquivo, char* linha);

// ========================================
// CONSTANTES
// ========================================

#define MAX_LINHA 200

#endif // PALINDROMO_H