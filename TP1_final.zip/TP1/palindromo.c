/**
 * UNIVERSIDADE FEDERAL DE ALFENAS (UNIFAL-MG)
 * Bacharelado em Ciência da Computação
 * Disciplina: AEDS II - DCE792
 * Professor: Iago Augusto de Carvalho
 * 
 * Trabalho Prático 1 - Verificador de Palíndromos
 * 
 * Integrantes do Grupo:
 * - Gabriela Mazon Rabello de Souza - 2025.1.08.006
 * - Luiz Gabriel da Silva Cabrera - 2024.1.08.047
 * - Murilo Antonio da Silva - 2025.1.08.019
 * 
 * Data: 23/09/2025
 */

#include "palindromo.h"
#include <stdio.h>
#include <stdlib.h>

// ========================================
// ESTRUTURAS DE DADOS (Lista, Pilha, Fila)
// ========================================

Lista* criarLista() {
    Lista* lista = (Lista*)malloc(sizeof(Lista));
    lista->inicio = NULL;
    return lista;
}

void inserirLista(Lista* lista, char elemento) {
    No* novoNo = (No*)malloc(sizeof(No));
    novoNo->dado = elemento;
    novoNo->proximo = lista->inicio;
    lista->inicio = novoNo;
}

void liberarLista(Lista* lista) {
    No* atual = lista->inicio;
    while (atual != NULL) {
        No* proximo = atual->proximo;
        free(atual);
        atual = proximo;
    }
    free(lista);
}

Pilha* criarPilha() {
    Pilha* pilha = (Pilha*)malloc(sizeof(Pilha));
    pilha->topo = NULL;
    return pilha;
}

void empilhar(Pilha* pilha, char elemento) {
    No* novoNo = (No*)malloc(sizeof(No));
    novoNo->dado = elemento;
    novoNo->proximo = pilha->topo;
    pilha->topo = novoNo;
}

char desempilhar(Pilha* pilha) {
    if (pilha->topo == NULL) return '\0';
    No* temp = pilha->topo;
    char elemento = temp->dado;
    pilha->topo = temp->proximo;
    free(temp);
    return elemento;
}

int pilhaVazia(Pilha* pilha) {
    return pilha->topo == NULL;
}

void liberarPilha(Pilha* pilha) {
    while (!pilhaVazia(pilha)) {
        desempilhar(pilha);
    }
    free(pilha);
}

Fila* criarFila() {
    Fila* fila = (Fila*)malloc(sizeof(Fila));
    fila->inicio = NULL;
    fila->fim = NULL;
    return fila;
}

void enfileirar(Fila* fila, char elemento) {
    No* novoNo = (No*)malloc(sizeof(No));
    novoNo->dado = elemento;
    novoNo->proximo = NULL;

    if (fila->fim == NULL) {
        fila->inicio = fila->fim = novoNo;
    } else {
        fila->fim->proximo = novoNo;
        fila->fim = novoNo;
    }
}

char desenfileirar(Fila* fila) {
    if (fila->inicio == NULL) return '\0';

    No* temp = fila->inicio;
    char elemento = temp->dado;
    fila->inicio = fila->inicio->proximo;

    if (fila->inicio == NULL) {
        fila->fim = NULL;
    }

    free(temp);
    return elemento;
}

int filaVazia(Fila* fila) {
    return fila->inicio == NULL;
}

void liberarFila(Fila* fila) {
    while (!filaVazia(fila)) {
        desenfileirar(fila);
    }
    free(fila);
}

// ========================================
// FUNÇÕES AUXILIARES
// ========================================

int ehAlfanumerico(char c) {
    return (c >= 'a' && c <= 'z') ||
           (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9');
}

char paraMinusculo(char c) {
    if (c >= 'A' && c <= 'Z') {
        return c + 32;
    }
    return c;
}

void limparTexto(char* entrada, char* saida) {
    int j = 0;
    for (int i = 0; entrada[i] != '\0'; i++) {
        char c = entrada[i];
        if (ehAlfanumerico(c)) {
            saida[j++] = paraMinusculo(c);
        } else if (c == 'á' || c == 'à' || c == 'â' || c == 'ã' || c == 'Á' || c == 'À' || c == 'Â' || c == 'Ã')
            saida[j++] = 'a';
        else if (c == 'é' || c == 'ê' || c == 'É' || c == 'Ê')
            saida[j++] = 'e';
        else if (c == 'í' || c == 'Í')
            saida[j++] = 'i';
        else if (c == 'ó' || c == 'ô' || c == 'õ' || c == 'Ó' || c == 'Ô' || c == 'Õ')
            saida[j++] = 'o';
        else if (c == 'ú' || c == 'Ú')
            saida[j++] = 'u';
        else if (c == 'ç' || c == 'Ç')
            saida[j++] = 'c';
    }
    saida[j] = '\0';
}

int contarCaracteres(char* texto) {
    int count = 0;
    while (texto[count] != '\0') {
        count++;
    }
    return count;
}

int verificarPalindromo(char* texto) {
    char textoLimpo[MAX_LINHA];
    limparTexto(texto, textoLimpo);

    int tamanho = contarCaracteres(textoLimpo);
    if (tamanho <= 1) return 1;

   
    Lista* lista = criarLista();
    Pilha* pilha = criarPilha();
    Fila* fila = criarFila();

    // Inserir caracteres na lista, pilha e fila
    for (int i = 0; i < tamanho; i++) {
        inserirLista(lista, textoLimpo[i]);
        empilhar(pilha, textoLimpo[i]);
        enfileirar(fila, textoLimpo[i]);
    }

    // Verificação 
    int ehPalindromo = 1;
    while (!pilhaVazia(pilha) && !filaVazia(fila)) {
        char topoPilha = desempilhar(pilha);
        char inicioFila = desenfileirar(fila);
        
        if (topoPilha != inicioFila) {
            ehPalindromo = 0;
            break; 
        }
    }

    liberarLista(lista);
    liberarPilha(pilha);
    liberarFila(fila);

    return ehPalindromo;
}

// ========================================
// FUNÇÃO PARA LER LINHA DO ARQUIVO
// ========================================

int lerLinha(FILE* arquivo, char* linha) {
    int i = 0;
    int c;
    
    while ((c = fgetc(arquivo)) != EOF && c != '\n') {
        if (i < MAX_LINHA - 1) {
            linha[i++] = c;
        }
    }
    linha[i] = '\0';
    
    return (i > 0 || c != EOF); 
}

// ========================================
// FUNÇÃO PRINCIPAL
// ========================================

int main() {
    char linha[MAX_LINHA];
    FILE* arquivo;

    // Abre diretamente o arquivo entrada.txt
    arquivo = fopen("entrada.txt", "r");
    if (arquivo == NULL) {
        return 1;
    }

    // Lê e processa cada linha
    while (1) {
        int i = 0;
        int c;
        
        // Lê uma linha caractere por caractere
        while (i < MAX_LINHA - 1) {
            c = fgetc(arquivo);
            
            if (c == EOF) break;
            if (c == '\n') break;
            
            linha[i++] = c;
        }
        linha[i] = '\0';
        
        
        if (i == 0 && c == EOF) break;
        
        // Processa a linha (mesmo se vazia)
        int resultado = verificarPalindromo(linha);
        printf("%d\n", resultado);
        
        
        if (c == EOF) break;
    }

    fclose(arquivo);
    return 0;
}
